const FORM = document.getElementById("mbtiForm");
const OUT = document.getElementById("result");
const TYPE = document.getElementById("type");
const SUMM = document.getElementById("summary");
const SAVE = document.getElementById("saveBtn");

const DESCS = {
  ISTJ: "Práctico, responsable y organizado. Buen enfoque en procesos y datos.",
  ISFJ: "Confiable, orientado al servicio y al detalle. Empatía aplicada.",
  INFJ: "Idealista, estratégico y empático. Visión de largo plazo.",
  INTJ: "Analítico, independiente y planificador. Estrategias sólidas.",
  ISTP: "Lógico y resolutivo, aprende haciendo. Calma en crisis.",
  ISFP: "Práctico y sensible, valora la armonía y la estética.",
  INFP: "Creativo y guiado por valores. Busca propósito.",
  INTP: "Analítico y curioso. Ama comprender sistemas.",
  ESTP: "Enérgico, directo y orientado a la acción.",
  ESFP: "Sociable, espontáneo y práctico. Aprende con experiencias.",
  ENFP: "Creativo, entusiasta y con ideas. Motiva a los demás.",
  ENTP: "Ingenioso, desafía supuestos y propone alternativas.",
  ESTJ: "Organizado, orientado a resultados y liderazgo práctico.",
  ESFJ: "Colaborativo, comunicativo y cuidadoso de las personas.",
  ENFJ: "Líder empático, promueve el desarrollo del grupo.",
  ENTJ: "Decidido, estratégico y orientado a metas ambiciosas.",
};

FORM.addEventListener("submit", (e) => {
  e.preventDefault();
  const data = new FormData(FORM);
  const counts = { E: 0, I: 0, S: 0, N: 0, T: 0, F: 0, J: 0, P: 0 };

  for (const [name, value] of data.entries()) {
    counts[value] = (counts[value] || 0) + 1;
  }

  const ei = counts.E >= counts.I ? "E" : "I";
  const sn = counts.S >= counts.N ? "S" : "N";
  const tf = counts.T >= counts.F ? "T" : "F";
  const jp = counts.J >= counts.P ? "J" : "P";

  const code = `${ei}${sn}${tf}${jp}`;
  TYPE.textContent = code;
  SUMM.textContent = DESCS[code] || "Tipo mixto.";

  OUT.classList.remove("hidden");

  // Guardar en localStorage
  localStorage.setItem(
    "mbti_result",
    JSON.stringify({ code, counts, ts: Date.now() })
  );

  // Si luego conectan backend, se puede POSTEAR:
  // fetch('http://localhost:3000/api/mbti', {
  //   method: 'POST',
  //   headers: {'Content-Type':'application/json', 'Authorization': 'Bearer <token>'},
  //   body: JSON.stringify({ type: code, answers: Object.fromEntries(data) })
  // });
});

SAVE.addEventListener("click", () => {
  alert("Resultado guardado localmente ✅");
});
